﻿using System;
namespace LA1305_Adventure_Game
{
    class Program
    {
        static int playerHealth = 100;
        static int playerGold = 0;
        static int playerAttack = 10;
        static int playerDefense = 0;
        static Random random = new Random();

        static void Main(string[] args)
        {
            Console.WriteLine("Willkommen zum Abenteuer-Spiel!");

            while (true)
            {
                Console.WriteLine("\nWas möchtest du tun?");
                Console.WriteLine("1. Erkunden");
                Console.WriteLine("2. Laden");
                Console.WriteLine("3. Status anzeigen");
                Console.WriteLine("4. Beenden");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Clear();
                        Explore();
                        break;
                    case "2":
                        Console.Clear();
                        VisitShop();
                        break;
                    case "3":
                        Console.Clear();
                        ShowStatus();
                        break;
                    case "4":
                        Console.WriteLine("Danke fürs Spielen! Bis zum nächsten Mal.");
                        return;
                    default:
                        Console.WriteLine("Ungültige Wahl. Bitte versuche es erneut.");
                        break;
                }
            }
        }

        static void Explore()
        {
            Console.WriteLine("\nDu erkundest die Umgebung...");
            int encounter = random.Next(1, 4);

            switch (encounter)
            {
                case 1:
                    FindGold();
                    break;
                case 2:
                    FightEnemy();
                    break;
                case 3:
                    Console.WriteLine("Du hast nichts gefunden.");
                    break;
            }
        }

        static void FindGold()
        {
            int goldFound = random.Next(5, 21);
            playerGold += goldFound;
            Console.WriteLine($"Du hast {goldFound} Gold gefunden! Du hast jetzt {playerGold} Gold.");
        }

        static void FightEnemy()
        {
            Console.WriteLine("Du triffst auf einen Feind!");

            int enemyHealth = random.Next(20, 51);
            int enemyAttack = random.Next(5, 16);

            while (enemyHealth > 0 && playerHealth > 0)
            {
                Console.WriteLine($"Feind-Gesundheit: {enemyHealth}");
                Console.WriteLine($"Deine Gesundheit: {playerHealth}");
                Console.WriteLine("Was möchtest du tun?");
                Console.WriteLine("1. Angreifen");
                Console.WriteLine("2. Fliehen");

                string choice = Console.ReadLine();

                if (choice == "1")
                {
                    Console.Clear();
                    enemyHealth -= playerAttack;
                    Console.WriteLine($"Du greifst an und verursachst {playerAttack} Schaden.");

                    if (enemyHealth > 0)
                    {
                        enemyAttack -= playerDefense;
                        playerHealth -= enemyAttack;
                        Console.WriteLine($"Der Feind greift zurück und verursacht {enemyAttack} Schaden.");
                    }
                    else
                    {
                        Console.WriteLine("Du hast den Feind besiegt!");
                        int goldDropped = random.Next(15, 31);
                        playerGold += goldDropped;
                        Console.WriteLine($"Du hast {goldDropped} Gold erhalten! Du hast jetzt {playerGold} Gold.");
                    }
                }
                else if (choice == "2")
                {
                    Console.Clear();
                    Console.WriteLine("Du fliehst vor dem Kampf!");
                    break;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Ungültige Wahl.");
                }
            }

            if (playerHealth <= 0)
            {
                Console.WriteLine("Du wurdest besiegt! Spiel ist vorbei.");
                Environment.Exit(0);
            }
        }

        static void VisitShop()
        {
            Console.WriteLine("\nWillkommen im laden!");
            Console.WriteLine("1. Schwert (+10 Angriff) - 50 Gold");
            Console.WriteLine("2. Axt (+20 Angriff) - 100 Gold");
            Console.WriteLine("3. Rüstung (+10 Verteidigung) - 100 Gold");
            Console.WriteLine("4. Heilung (+100 Gesundheit) - 20 Gold");
            Console.WriteLine("5. Zurück");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    BuyWeapon(50, 10);
                    break;
                case "2":
                    BuyWeapon(100, 20);
                    break;
                case"3":
                    buyArmor(100, 10);
                    break;
                case "4":
                    Heal(20);
                    break;
                case "5":
                    Console.Clear();
                    Console.WriteLine("Du verlässt den Laden.");
                    break;
                default:
                    Console.WriteLine("Ungültige Wahl.");
                    break;
            }
        }

        static void BuyWeapon(int cost, int attackBoost)
        {
            if (playerGold >= cost)
            {
                playerGold -= cost;
                playerAttack += attackBoost;
                Console.WriteLine($"Du hast eine neue Waffe gekauft! Dein Angriff beträgt jetzt {playerAttack}. Du hast noch {playerGold} Gold.");
            }
            else
            {
                Console.WriteLine("Du hast nicht genug Gold.");
            }
        }
        static void buyArmor(int cost, int Defense)
        {
            if (playerGold >= cost)
            {
                playerGold -= cost;
                playerDefense += Defense;
                Console.WriteLine($"Du hast eine Rüstung gekauft! Deine Verteidigung beträgt jetzt {playerDefense}. Du hast noch {playerGold} Gold.");
            }
            else
            {
                Console.WriteLine("Du hast nicht genug Gold");
            }
        }
        static void Heal(int cost)
        {
            if (playerHealth < 100)
            {


                if (playerGold >= cost)
                {
                    playerHealth = 100;
                    playerGold -= cost;
                    Console.WriteLine($"Sie wurden um 100 Gesundheit geheilt. Ihre Gesundheit beträgt jetzt wieder 100/100. Du hast noch {playerGold} Gold.");
                }
                else
                {
                    Console.WriteLine("Du hast nicht genug Gold.");
                }
            }
            else
            {
                Console.WriteLine("Du hast schon volle Lebenspunkte");
            }
        }

        static void ShowStatus()
        {
            Console.WriteLine($"\nStatus:");
            Console.WriteLine($"Gesundheit: {playerHealth}");
            Console.WriteLine($"Gold: {playerGold}");
            Console.WriteLine($"Angriff: {playerAttack}");
        }
    }
}
